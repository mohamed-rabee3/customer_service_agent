
import "./styles/index.css";

import AnalyticsPage from "./pages/AnalyticsPage.tsx";


function App() {

  return (
    <div>
   
     
      <AnalyticsPage></AnalyticsPage>
      
    </div>

  );
}

export default App
